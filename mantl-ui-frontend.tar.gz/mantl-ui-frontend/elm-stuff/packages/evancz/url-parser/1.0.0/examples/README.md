# Run the Examples

To run the examples in this folder, follow the following steps:

```bash
git clone https://github.com/evancz/url-parser.git
cd url-parser
cd examples
elm-reactor
```

This will navigate into the `examples/` directory and start `elm-reactor`. From here, go to [http://localhost:8000](http://localhost:8000) and start clicking on `.elm` files to see them in action.