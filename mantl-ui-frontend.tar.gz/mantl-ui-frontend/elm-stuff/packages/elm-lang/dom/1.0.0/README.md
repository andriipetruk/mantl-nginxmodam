# Low-level DOM bindings

This is not for general use. It backs libraries like `elm-lang/mouse` and `elm-lang/window` which should cover your needs in most cases. In the rare case that libraries like that do not seem to cover your scenario, it is best to bring it up with the community. Ask around and learn stuff first!