# elm-task-extra
Additional functions for working with tasks

